package operations;

public class MyNumber implements AdvIntOperations {

	@Override
	public boolean isOdd(int n) {
		// TODO Auto-generated method stub
		if(n % 2 != 0) {
			return true;
		}
		else {
		
		return false;
		}
	}

	@Override
	public boolean isEven(int n) {
		// TODO Auto-generated method stub
		if(n % 2 == 0) {
			return true;
		}
		else {
		
		return false;
		}
	}

	@Override
	public boolean isPrime(int n) {
		// TODO Auto-generated method stub
		if(n == 0 || n == 1) return false;
		
		
			for(int i = 2; i*i <= n;i++ ) {
				if(n % i == 0) {
					return false;
				}
			}
		
		
		return true;
	}

	@Override
	public double calFactorial(int n) {
		// TODO Auto-generated method stub
		
		int factorial = 1;
		
		for(int i = 2; i <= n; i++ ) {
			factorial *= i;
		}
		
		return factorial;
	}

}
