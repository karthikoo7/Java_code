package staff;

public class SalesManager extends Emp {
	
	private double salesTarget;
	private double perCommision;
	public SalesManager() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SalesManager(String name, int d, int m, int y, int empId, double salary, double salesTarget,
			double perCommision) {
		super(name, d, m, y, empId, salary);
		this.salesTarget = salesTarget;
		this.perCommision = perCommision;
	}
	
	public void display() {
		super.display();
		System.out.println("TARGET :  " + salesTarget + " Commision : " + perCommision);
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString() + "TARGET :  " + salesTarget + " Commision : " + perCommision;
	}
	
	public double calSalary() {
		// return super.calSalary() + (salesTarget * perCommision/100);  // salary - private
		return salary + (salesTarget * perCommision/100); //salary - protected in the super class
	}
	

}
