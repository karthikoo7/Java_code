package staff;

public class Programmer extends Emp {
	
	private String projectTitle;
	private int extraHours;
	private double chargePerExtraHour;
	
	public Programmer() {
		super();
		// TODO Auto-generated constructor stub
		this.projectTitle = "NA";
	}

	public Programmer(String name, int d, int m, int y, int empId, double salary, String projectTitle, int extraHours,
			int chargePerExtraHour) {
		super(name, d, m, y, empId, salary);
		this.projectTitle = projectTitle;
		this.extraHours = extraHours;
		this.chargePerExtraHour = chargePerExtraHour;
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		super.display();
		System.out.println("PROJ TITLE : " + projectTitle + " EXTRS HOUR : " + extraHours + " CHARGE PER EXTRA HOUR : " + chargePerExtraHour);
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString() + "PROJ TITLE : " + projectTitle + " EXTRS HOUR : " + extraHours + " CHARGE PER EXTRA HOUR : " + chargePerExtraHour;
	}
	
	public double calSalary() {
		
		return salary + (extraHours * chargePerExtraHour); // salary data memeber protected not private
	}
	
	
	
	

}
